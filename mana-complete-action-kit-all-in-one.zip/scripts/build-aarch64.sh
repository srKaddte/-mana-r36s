#!/usr/bin/env bash
set -euo pipefail

ROOT=/workspace
SRC_ARCHIVE="$ROOT/source/mana-master.tar.gz"
WORK="$ROOT/.build"
SRC="$WORK/mana-master"
BUILD="$WORK/build"
STAGE="$WORK/stage"
PORT="$ROOT/port"
DIST="$ROOT/dist"

rm -rf "$WORK" "$DIST"
mkdir -p "$WORK" "$DIST"
tar -xzf "$SRC_ARCHIVE" -C "$WORK"

# The archive supplied for this project is Mana 0.8.0.
[ -f "$SRC/CMakeLists.txt" ] || { echo 'Mana source not found'; exit 1; }

cmake -S "$SRC" -B "$BUILD" \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_INSTALL_PREFIX=/usr \
  -DWITH_OPENGL=ON \
  -DENABLE_NLS=OFF \
  -DENABLE_MANASERV=ON \
  -DUSE_SYSTEM_ENET=OFF \
  -DUSE_SYSTEM_GUICHAN=OFF

cmake --build "$BUILD" --parallel "$(nproc)"

BIN="$BUILD/src/mana"
[ -x "$BIN" ] || { echo 'Mana executable was not produced'; exit 1; }

mkdir -p "$STAGE"
cp -a "$PORT/." "$STAGE/"
mkdir -p "$STAGE/mana"
cp "$BIN" "$STAGE/mana/mana.aarch64"
chmod +x "$STAGE/mana/mana.aarch64"

# The old prebuilt Guichan library was only needed by the old Debian binary.
# The new build links Guichan statically, so do not ship that incompatible copy.
rm -f "$STAGE/mana/libs.aarch64/libguichan.so.0.8"

# The new build may use the builder's libxml2 SONAME. Keep the old .16 out of
# the runtime package; diagnostics will tell us exactly what the new ELF needs.
rm -f "$STAGE/mana/libs.aarch64/libxml2.so.16"

printf '%s\n' '=== Mana AArch64 ELF diagnostics ===' > "$DIST/diagnostics.txt"
file "$STAGE/mana/mana.aarch64" | tee -a "$DIST/diagnostics.txt"
readelf -l "$STAGE/mana/mana.aarch64" | grep -E 'Requesting program interpreter|INTERP' | tee -a "$DIST/diagnostics.txt" || true
printf '%s\n' '--- NEEDED ---' | tee -a "$DIST/diagnostics.txt"
readelf -d "$STAGE/mana/mana.aarch64" | grep NEEDED | tee -a "$DIST/diagnostics.txt" || true
printf '%s\n' '--- GLIBC versions ---' | tee -a "$DIST/diagnostics.txt"
readelf --version-info "$STAGE/mana/mana.aarch64" | grep -o 'GLIBC_[0-9][0-9.]*' | sort -Vu | tee -a "$DIST/diagnostics.txt" || true

# The PortMaster AArch64 builder is intentionally an older glibc environment.
# Reject the previous failure mode rather than generating a known-bad port.
if readelf --version-info "$STAGE/mana/mana.aarch64" | grep -q 'GLIBC_2\.43'; then
  echo 'ERROR: build still requires GLIBC_2.43' | tee -a "$DIST/diagnostics.txt"
  exit 2
fi

rm -f "$DIST/mana-r36s-portmaster-0.8.0-aarch64.zip"
(
  cd "$STAGE"
  zip -qr "$DIST/mana-r36s-portmaster-0.8.0-aarch64.zip" .
)

echo '=== PACKAGE ===' | tee -a "$DIST/diagnostics.txt"
unzip -l "$DIST/mana-r36s-portmaster-0.8.0-aarch64.zip" | tail -n +1 | tee -a "$DIST/diagnostics.txt"
