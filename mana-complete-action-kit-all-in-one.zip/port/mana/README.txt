Mana Client 0.8.0 AArch64 data and executable.
