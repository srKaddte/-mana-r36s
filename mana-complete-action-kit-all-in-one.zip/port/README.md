# The Mana World — PortMaster

Mana Client 0.8.0, AArch64 build for R36S/PortMaster.
The executable and game data are bundled. System SDL/graphics libraries are left to PortMaster.
If it fails, check `mana/log.txt` in the installed port directory.
