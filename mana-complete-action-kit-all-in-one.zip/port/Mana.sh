#!/bin/bash
XDG_DATA_HOME=${XDG_DATA_HOME:-$HOME/.local/share}

if [ -d "/opt/system/Tools/PortMaster/" ]; then
    controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
    controlfolder="/opt/tools/PortMaster"
elif [ -d "$XDG_DATA_HOME/PortMaster/" ]; then
    controlfolder="$XDG_DATA_HOME/PortMaster"
else
    controlfolder="/roms/ports/PortMaster"
fi

source "$controlfolder/control.txt"
[ -f "${controlfolder}/mod_${CFW_NAME}.txt" ] && source "${controlfolder}/mod_${CFW_NAME}.txt"
get_controls

GAMEDIR=/$directory/ports/mana/
CONFDIR="$GAMEDIR/conf/"
mkdir -p "$CONFDIR"
cd "$GAMEDIR"

> "$GAMEDIR/log.txt" && exec > >(tee "$GAMEDIR/log.txt") 2>&1

echo "=== Mana PortMaster launcher ==="
echo "CFW_NAME=$CFW_NAME"
echo "DEVICE_ARCH=$DEVICE_ARCH"
echo "DEVICE_CPU=$DEVICE_CPU"
echo "GAMEDIR=$GAMEDIR"

if [ "$DEVICE_ARCH" != "aarch64" ]; then
    echo "ERROR: This package requires aarch64; detected: $DEVICE_ARCH"
    pm_finish
    exit 1
fi

export XDG_DATA_HOME="$CONFDIR"
export XDG_CONFIG_HOME="$CONFDIR"
export LD_LIBRARY_PATH="$GAMEDIR/libs.${DEVICE_ARCH}:$LD_LIBRARY_PATH"
export SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig"

chmod +x "$GAMEDIR/mana.aarch64"

if [ -x "$GPTOKEYB" ]; then
    "$GPTOKEYB" "mana.aarch64" -c "./mana.gptk.0" &
    GPTOPID=$!
fi

pm_platform_helper "$GAMEDIR/mana.aarch64"

echo "Starting Mana..."
./mana.aarch64 --fullscreen -d "$GAMEDIR/data"
RET=$?

[ -n "$GPTOPID" ] && kill "$GPTOPID" 2>/dev/null
echo "Mana exited with code $RET"
pm_finish
exit $RET
