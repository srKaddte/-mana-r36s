# Mana 0.8.0 — complete PortMaster AArch64 build kit

This bundle contains everything prepared for the R36S AArch64 build:

- `source/mana-master.tar.gz` — Mana source supplied for this project.
- `port/` — current PortMaster package template, including launcher, metadata, game data, and the libraries used by the previous test.
- `scripts/build-aarch64.sh` — reproducible build/package script.
- `.github/workflows/build-aarch64.yml` — GitHub Actions workflow.
- `prebuilt/` — previous test ZIP, retained for reference/rollback.

## Build

1. Create a GitHub repository.
2. Upload this entire folder's contents to the repository root.
3. Open **Actions → Build Mana 0.8.0 AArch64 PortMaster → Run workflow**.
4. Download the artifact named `mana-r36s-portmaster-aarch64`.

The workflow enables ARM64 emulation and runs the build inside the official PortMaster AArch64 builder. It also records ELF dependencies and GLIBC versions and refuses to package the old `GLIBC_2.43` failure mode.

The previous Debian binary is not used by the build. Guichan is built from Mana's bundled source, and the old Guichan `.so`/libxml2 `.16` copies are removed from the newly generated package so they cannot mask the new binary's actual dependencies.
