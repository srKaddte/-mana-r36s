/*
 *  The Mana Client
 *  Copyright (C) 2026  The Mana Developers
 *
 *  This file is part of The Mana Client.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once

#include "net/serverinfo.h"
#include "net/serverstatusbackend.h"

#include <memory>

/**
 * Probes a server to find out whether it is online. The probe does not
 * require authentication.
 *
 * The actual work is done by a backend matching the server type. The
 * connection is processed on the main thread by calling update().
 */
class ServerStatusChecker
{
public:
    explicit ServerStatusChecker(const ServerInfo &server);
    ~ServerStatusChecker();

    ServerStatusChecker(const ServerStatusChecker &) = delete;
    ServerStatusChecker &operator=(const ServerStatusChecker &) = delete;

    /**
     * Processes the connection. Should be called regularly until the state
     * is no longer ServerStatus::State::Checking.
     */
    void update();

    const ServerStatus &getStatus() const { return mStatus; }

private:
    const ServerInfo mServer;
    std::unique_ptr<Net::ServerStatusBackend> mBackend;
    ServerStatus mStatus;
};
