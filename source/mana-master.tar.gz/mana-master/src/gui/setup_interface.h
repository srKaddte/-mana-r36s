/*
 *  The Mana Client
 *  Copyright (C) 2004-2009  The Mana World Development Team
 *  Copyright (C) 2009-2026  The Mana Developers
 *
 *  This file is part of The Mana Client.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once

#include "being.h"
#include "guichanfwd.h"

#include "gui/widgets/setuptab.h"

#include <guichan/actionlistener.hpp>
#include <guichan/keylistener.hpp>

class Setup_Interface : public SetupTab, public gcn::ActionListener,
                    public gcn::KeyListener
{
    public:
        Setup_Interface();
        ~Setup_Interface() override;

        void apply() override;
        void cancel() override;

        void action(const gcn::ActionEvent &event) override;

    private:
        bool mShowMonsterDamageEnabled;
        bool mVisibleNamesEnabled;
        bool mNameEnabled;
        bool mNPCLogEnabled;
        bool mPickupChatEnabled;
        bool mPickupParticleEnabled;
        int mPickupRange;
        double mOpacity;
        Being::Speech mSpeechMode;

        std::unique_ptr<gcn::ListModel> mLanguageListModel;
        std::unique_ptr<gcn::ListModel> mThemesListModel;
        std::unique_ptr<gcn::ListModel> mFontSizeListModel;

        gcn::CheckBox *mShowMonsterDamageCheckBox;
        gcn::CheckBox *mVisibleNamesCheckBox;
        gcn::CheckBox *mNameCheckBox;
        gcn::CheckBox *mNPCLogCheckBox;

        gcn::Label *mPickupNotifyLabel;
        gcn::CheckBox *mPickupChatCheckBox;
        gcn::CheckBox *mPickupParticleCheckBox;

        gcn::Slider *mPickupRangeSlider;
        gcn::Label *mPickupRangeValueLabel;

        gcn::Slider *mSpeechSlider;
        gcn::Label *mSpeechLabel;
        gcn::Slider *mAlphaSlider;

        gcn::DropDown *mLanguageDropDown = nullptr;
        gcn::DropDown *mThemeDropDown;
        gcn::DropDown *mFontSizeDropDown;

};
