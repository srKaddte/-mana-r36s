/*
 *  The Mana Client
 *  Copyright (C) 2004-2009  The Mana World Development Team
 *  Copyright (C) 2009-2026  The Mana Developers
 *
 *  This file is part of The Mana Client.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "gui/charselectdialog.h"

#include "client.h"
#include "localplayer.h"
#include "log.h"
#include "textpopup.h"
#include "units.h"

#include "gui/changeemaildialog.h"
#include "gui/changepassworddialog.h"
#include "gui/charcreatedialog.h"
#include "gui/confirmdialog.h"
#include "gui/sdlinput.h"
#include "gui/unregisterdialog.h"

#include "gui/widgets/button.h"
#include "gui/widgets/container.h"
#include "gui/widgets/label.h"
#include "gui/widgets/layout.h"
#include "gui/widgets/playerbox.h"
#include "gui/widgets/spacer.h"

#include "net/charhandler.h"
#include "net/logindata.h"
#include "net/loginhandler.h"
#include "net/net.h"

#include "utils/gettext.h"
#include "utils/stringutils.h"

#include <guichan/font.hpp>

#include <string>
#include <cassert>

// Character slots per row in the dialog
static const int SLOTS_PER_ROW = 5;

/**
 * Listener for confirming character deletion.
 */
class CharDeleteConfirm : public ConfirmDialog
{
    public:
        CharDeleteConfirm(CharSelectDialog *m, int index):
            ConfirmDialog(_("Confirm Character Delete"),
                    _("Are you sure you want to delete this character?"), m),
            mMaster(m),
            mIndex(index)
        {
        }

        void action(const gcn::ActionEvent &event) override
        {
            if (event.getId() == "yes")
                mMaster->attemptCharacterDelete(mIndex);

            ConfirmDialog::action(event);
        }

    private:
        CharSelectDialog *mMaster;
        int mIndex;
};

class CharacterDisplay : public Container, public gcn::MouseListener
{
    public:
        CharacterDisplay(CharSelectDialog *charSelectDialog);

        void setCharacter(const Net::Character *character);

        const Net::Character *getCharacter() const
        { return mCharacter; }

        /** The slot shown here, or -1 when empty. */
        int getSlot() const
        { return mCharacter ? mCharacter->slot : -1; }

        void requestFocus() override;

        void mouseMoved(gcn::MouseEvent &event) override;
        void mouseExited(gcn::MouseEvent &event) override;

        void setActive(bool active);

    private:
        void update();

        const Net::Character *mCharacter = nullptr;

        PlayerBox *mPlayerBox;
        Label *mName;
        Button *mButton;
        Button *mDelete;

        /**
         * The character info popup
         * @note: This is a global object. One for all the characters.
         */
        static TextPopup *mTextPopup;
};

CharSelectDialog::CharSelectDialog(LoginData *loginData):
    Window(_("Account and Character Management")),
    mLoginData(loginData),
    mCharHandler(Net::getCharHandler())
{
    setCloseButton(false);

    mAccountNameLabel = new Label(loginData->username);
    mSwitchLoginButton = new Button(_("Logout"), "switch", this);
    mChangePasswordButton = new Button(_("Change Password"), "change_password",
                                       this);

    int optionalActions = Net::getLoginHandler()->supportedOptionalActions();

    ContainerPlacer place;
    place = getPlacer(0, 0);

    place(0, 0, mAccountNameLabel, 2);
    place(0, 1, mSwitchLoginButton);
    place(0, 2, new Spacer);
    place(0, 3, mChangePasswordButton);

    if (optionalActions & Net::LoginHandler::ChangeEmail)
    {
        mChangeEmailButton = new Button(_("Change Email"),
                                        "change_email", this);
        place(0, 4, mChangeEmailButton);
    }

    place(0, 5, new Spacer);

    if (optionalActions & Net::LoginHandler::Unregister)
    {
        mUnregisterButton = new Button(_("Unregister"),
                                       "unregister", this);
        place(0, 6, mUnregisterButton);
    }

    place = getPlacer(1, 0);

    for (int i = 0; i < (int)mLoginData->characterSlots; i++)
    {
        mCharacterEntries.push_back(new CharacterDisplay(this));
        place(i % SLOTS_PER_ROW, i / SLOTS_PER_ROW, mCharacterEntries[i]);
    }

    reflowLayout();

    addKeyListener(this);

    center();
    setVisible(true);

    Net::getCharHandler()->setCharSelectDialog(this);
    mCharacterEntries[0]->requestFocus();
}

CharSelectDialog::~CharSelectDialog() = default;

void CharSelectDialog::action(const gcn::ActionEvent &event)
{
    // Check if a button of a character was pressed
    const gcn::Widget *sourceParent = event.getSource()->getParent();
    int selected = -1;
    for (int i = 0; i < (int)mCharacterEntries.size(); ++i)
    {
        if (mCharacterEntries[i] == sourceParent)
        {
            selected = i;
            break;
        }
    }

    const std::string &eventId = event.getId();

    if (selected != -1)
    {
        if (eventId == "use")
        {
            attemptCharacterSelect(selected);
        }
        else if (eventId == "new"
                 && !mCharacterEntries[selected]->getCharacter())
        {
            // Start new character dialog
            auto *charCreateDialog =
                    new CharCreateDialog(this, selected);
            mCharHandler->setCharCreateDialog(charCreateDialog);
        }
        else if (eventId == "delete"
                 && mCharacterEntries[selected]->getCharacter())
        {
            new CharDeleteConfirm(this, selected);
        }
    }
    else if (eventId == "switch")
    {
        Client::setState(State::SwitchLogin);
    }
    else if (eventId == "change_password")
    {
        Client::setState(State::ChangePassword);
    }
    else if (eventId == "change_email")
    {
        Client::setState(State::ChangeEmail);
    }
    else if (eventId == "unregister")
    {
        Client::setState(State::Unregister);
    }
}

void CharSelectDialog::keyPressed(gcn::KeyEvent &keyEvent)
{
    gcn::Key key = keyEvent.getKey();

    if (key.getValue() == Key::ESCAPE)
    {
        action(gcn::ActionEvent(mSwitchLoginButton,
                                mSwitchLoginButton->getActionEventId()));
    }
}

/**
 * Communicate character deletion to the server.
 */
void CharSelectDialog::attemptCharacterDelete(int index)
{
    if (mLocked)
        return;

    mCharHandler->deleteCharacter(mCharacterEntries[index]->getSlot());
    lock();
}

/**
 * Communicate character selection to the server.
 */
void CharSelectDialog::attemptCharacterSelect(int index)
{
    if (mLocked)
        return;

    setVisible(false);
    mCharHandler->chooseCharacter(mCharacterEntries[index]->getSlot());
    lock();
}

void CharSelectDialog::setCharacters(const Net::Characters &characters)
{
    // Reset previous characters
    for (auto *characterEntry : mCharacterEntries)
        characterEntry->setCharacter(nullptr);

    for (const auto &character : characters)
    {
        // Slots Number start at 1 for Manaserv, so we offset them by one.
        int characterSlot = character.slot;
        if (Net::getNetworkType() == ServerType::ManaServ && characterSlot > 0)
            --characterSlot;

        if (characterSlot >= (int)mCharacterEntries.size())
        {
            Log::warn("Slot out of range: %d", character.slot);
            continue;
        }

        mCharacterEntries[characterSlot]->setCharacter(&character);
    }
}

void CharSelectDialog::lock()
{
    assert(!mLocked);
    setLocked(true);
}

void CharSelectDialog::unlock()
{
    setLocked(false);
}

void CharSelectDialog::setLocked(bool locked)
{
    mLocked = locked;

    mSwitchLoginButton->setEnabled(!locked);
    mChangePasswordButton->setEnabled(!locked);
    if (mUnregisterButton)
        mUnregisterButton->setEnabled(!locked);
    if (mChangeEmailButton)
        mChangeEmailButton->setEnabled(!locked);

    for (auto &characterEntry : mCharacterEntries)
        characterEntry->setActive(!mLocked);
}

bool CharSelectDialog::selectByName(const std::string &name,
                                    SelectAction action)
{
    if (mLocked)
        return false;

    for (int i = 0; i < (int)mCharacterEntries.size(); ++i)
    {
        if (const Net::Character *character = mCharacterEntries[i]->getCharacter())
        {
            if (character->dummy->getName() == name)
            {
                mCharacterEntries[i]->requestFocus();
                if (action == Choose)
                    attemptCharacterSelect(i);
                return true;
            }
        }
    }

    return false;
}


TextPopup *CharacterDisplay::mTextPopup = nullptr;

CharacterDisplay::CharacterDisplay(CharSelectDialog *charSelectDialog):
    mPlayerBox(new PlayerBox)
{
    mPlayerBox->addMouseListener(this);

    mName = new Label(std::string());
    mName->setAlignment(Graphics::CENTER);
    mButton = new Button("", "go", charSelectDialog);
    mDelete = new Button(_("Delete"), "delete", charSelectDialog);

    place(0, 0, mPlayerBox, 3, 5);
    place(0, 5, mName, 3);
    place(0, 6, mButton, 3);
    place(0, 7, mDelete, 3);

    update();

    setSize(80, 112 + mName->getHeight()
                    + mButton->getHeight()
                    + mDelete->getHeight());

    // Create the tooltip popup. It is shared by all instances and will get
    // deleted by the WindowContainer.
    if (!mTextPopup)
        mTextPopup = new TextPopup;
}

void CharacterDisplay::setCharacter(const Net::Character *character)
{
    mCharacter = character;
    mPlayerBox->setPlayer(character ? character->dummy.get() : nullptr);
    update();
}

void CharacterDisplay::requestFocus()
{
    mButton->requestFocus();
}

void CharacterDisplay::setActive(bool active)
{
    mButton->setEnabled(active);
    mDelete->setEnabled(active);
}

void CharacterDisplay::update()
{
    if (mCharacter)
    {
        const LocalPlayer *character = mCharacter->dummy.get();
        mButton->setCaption(_("Choose"));
        mButton->setActionEventId("use");
        mName->setCaption(strprintf("%s", character->getName().c_str()));
        mDelete->setVisible(true);
    }
    else
    {
        mButton->setCaption(_("Create"));
        mButton->setActionEventId("new");
        mName->setCaption(_("(empty)"));
        mDelete->setVisible(false);
    }

    // Recompute layout
    distributeResizedEvent();
}

void CharacterDisplay::mouseMoved(gcn::MouseEvent &event)
{
    int x = event.getX();
    int y = event.getY();

    if (event.getSource() == mPlayerBox && mCharacter)
    {
        int absX, absY;
        mPlayerBox->getAbsolutePosition(absX, absY);

        const auto level = strprintf(_("Level %d"),
                                     mCharacter->data.getAttribute(LEVEL));
        const auto money = Units::formatCurrency(
                                     mCharacter->data.getAttribute(MONEY));

        mTextPopup->show(x + absX, y + absY, level, money);
    }
    else
    {
        mTextPopup->setVisible(false);
    }
}

void CharacterDisplay::mouseExited(gcn::MouseEvent &event)
{
    mTextPopup->setVisible(false);
}
