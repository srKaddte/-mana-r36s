/*
 *  The Mana Client
 *  Copyright (C) 2004-2009  The Mana World Development Team
 *  Copyright (C) 2009-2026  The Mana Developers
 *
 *  This file is part of The Mana Client.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once

#include "gui/widgets/window.h"

#include <guichan/keylistener.hpp>
#include <guichan/actionlistener.hpp>

#include <list>

class IntTextField;
class Item;
class ItemPopup;
class Icon;

/**
 * Window used for selecting the amount of items to drop, trade or store.
 *
 * \ingroup Interface
 */
class ItemAmountWindow : public Window,
                         public gcn::ActionListener,
                         public gcn::KeyListener
{
    public:
        enum Usage {
            TradeAdd,
            ItemDrop,
            StoreAdd,
            StoreRemove,
        };

        /**
         * Called when receiving actions from widget.
         */
        void action(const gcn::ActionEvent &event) override;

        /**
         * Sets default amount value.
         */
        void resetAmount();

        // MouseListener
        void mouseMoved(gcn::MouseEvent &event) override;
        void mouseExited(gcn::MouseEvent &event) override;

        /**
         * Schedules the Item Amount window for deletion.
         */
        void close() override;

        void keyReleased(gcn::KeyEvent &keyEvent) override;

        /**
         * Creates the dialog, or bypass it if there aren't enough items.
         */
        static void showWindow(Usage usage, Window *parent, const Item *item,
                               int maxRange = 0);

        /**
         * Closes all instances.
         */
        static void closeAll();

        ~ItemAmountWindow() override;

    private:
        static void finish(int itemId, int itemIndex, int amount, Usage usage);

        using DialogList = std::list<ItemAmountWindow *>;
        static DialogList instances;

        ItemAmountWindow(Usage usage, Window *parent, const Item *item,
                         int maxRange);

        IntTextField *mItemAmountTextField;   /**< Item amount caption. */
        int mItemId;
        int mItemIndex;
        Icon *mItemIcon;

        int mMax;
        Usage mUsage;
        ItemPopup *mItemPopup;

        /**
         * Item Amount buttons.
         */
        gcn::Slider *mItemAmountSlide;

        bool mEnabledKeyboard;
};
