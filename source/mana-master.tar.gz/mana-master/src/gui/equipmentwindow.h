/*
 *  The Mana Client
 *  Copyright (C) 2004-2009  The Mana World Development Team
 *  Copyright (C) 2009-2026  The Mana Developers
 *
 *  This file is part of The Mana Client.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once

#include "equipment.h"

#include "gui/dragndrop.h"
#include "gui/widgets/window.h"

#include <guichan/actionlistener.hpp>

class Inventory;
class Item;
class ItemPopup;

/**
 * Equipment dialog.
 *
 * \ingroup Interface
 */
class EquipmentWindow : public Window,
                        public DragTarget,
                        public DragSource,
                        public gcn::ActionListener
{
    public:
        EquipmentWindow(Equipment *equipment);

        ~EquipmentWindow() override;

        /**
         * Draws the equipment window.
         */
        void draw(gcn::Graphics *graphics) override;

        bool handleDrop(const Drag &drag, int absX, int absY) override;

        void action(const gcn::ActionEvent &event) override;

        void mousePressed(gcn::MouseEvent& mouseEvent) override;
        void mouseDragged(gcn::MouseEvent &event) override;
        void mouseMoved(gcn::MouseEvent &event) override;
        void mouseExited(gcn::MouseEvent &event) override;
        void dragFinished(const Drag &drag, DragResult result) override;

        /**
         * Returns the current selected slot or -1 if none.
         */
        int getSelected() const
        { return mSelected; }

  protected:
        int mSelected = -1;             /**< Index of selected item. */
        Equipment *mEquipment;

    private:
        int getBoxIndex(int x, int y) const;
        Item *getItem(int x, int y) const;
        Item *getTwoHandedWeaponBlocking(int slotIndex) const;
        std::string getSlotName(int x, int y) const;

        void setSelected(int index);

        ItemPopup *mItemPopup;
        gcn::Button *mUnequip;
        int mClickedIndex = -1;
};

extern EquipmentWindow *equipmentWindow;
